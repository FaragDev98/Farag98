// Main JavaScript file
console.log('Welcome to Fabrica Course');