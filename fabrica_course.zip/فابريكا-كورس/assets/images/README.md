# Images Folder

This folder contains all image assets.