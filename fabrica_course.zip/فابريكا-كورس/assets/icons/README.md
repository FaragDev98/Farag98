# Icons Folder

This folder contains icons used in the project.